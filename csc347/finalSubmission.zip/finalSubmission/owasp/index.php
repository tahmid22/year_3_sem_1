<?
/*
| OWASP 2013 A2: BROKEN AUTHENTICATION AND SESSION MANAGMENT (SESSION FIXATION)
| EXPLANATION: When the user credendiatial can easily be extracted.
	For example:
		-> session is not random and unchanged between reuests
		-> password is not hashed and shown in the URL
| 
| FIX: 
	-> start new session for every login.
	-> hash/encrypt sensitive data
	-> have token and regenerate token in every request such as add, delete etc.
*/


/*
| OWASP 2013 A4: INSECURE DIRECT OBJECT REFERENCES
| EXPLANATION: When an application provides direct access to objects based on user-supplied input. With this attacker can bypass authorization.
| 
| FIX: by disable direct object references pr setup proper authorization. Setup indirect references.
	For example in the php code, regenerate random token after every request.
*/

        session_start(); 

	if(!isset($_SESSION['isLoggedIn']))$_SESSION['isLoggedIn']=False;
	$operation=$_REQUEST['operation'];
	$g_debug="";
	$g_errors="";

	require "lib/lib.php";
	if($operation == "login"){
		$username=$_REQUEST['username'];
		$passwd=$_REQUEST['passwd'];
		$dbconn = pg_connect_db();


/*
N: Injecting input to do modification in the data-base.
	For example if we have an insecure databse which asks user to enter in login and password,
	we can SQL inject up typing '1'='1-- which will always evaluate to true and we can modify DB
	by passing in query as we wish. 
 
FIX:
	1. Have prepare statements
	2. whitelist input.

*/

/*
| OWASP 2013 A6: SENSITIVE DATA EXPOSURE
| EXPLANATION: When the attacker is easily able to get user's sensitive data from the database such as password.
| 
| FIX: By hashing the data and even better do not show it to URL directly and perform in the backgroup.
	This way it will be more work to even get the hashed data.
	For example in the php code hash the password such as have:
	$password = md5($password)
*/

/*
| OWASP 2013 A3: CROSS SITE SCRIPTING
| EXPLANATION: Web app vulnerability which allows the attacker to store Javascript onto the web page which are viewed by 	other users. This can be used to send secure ifo and browser cookies to the attacker.
| 
| FIX: For example in php code have:

$expression = clean_input($expression);
if (valid_exp($expression)){ #DO }
function valid_exp($data){
	$valid_pattern = 'regex of the patterns we want to whitelist with'; 
	$final = preg_match($valid_pattern, $data)
}

fuction clean_input($data){
	$data = trim($data)
	$data = stripslashes($data)
	$data = htmlentities($data)
	return $data 
}
*/


+--------------------------------------------------------------------------
| OWASP 2013 A1: INJECTION (SQL Injection)
| EXPLANATION: Though it looks like this is using a prepared statement, 
| 	in fact all parameters are supplied in the text of the query.
| FIX: 
|	$query= "SELECT username, passwd FROM account WHERE username=$1 AND passwd=$2";
|	$result = pg_prepare($dbconn, "prep_statement1", $query);
|	$result = pg_execute($dbconn, "prep_statement1", array($username, $passwd));
+--------------------------------------------------------------------------

		$query= "SELECT username, passwd FROM account WHERE username='$username' AND passwd='$passwd'";
		$result = pg_prepare($dbconn, "prep_statement", $query);
		$result = pg_execute($dbconn, "prep_statement", array(username, password));
		if($row = pg_fetch_row($result)) {
			$_SESSION['username']=$row[0];
			$_SESSION['isLoggedIn']=True;
		} else {
			$g_debug = "$username not logged in";
			$_SESSION['isLoggedIn']=False;
		}
/*
OWASP 2013 A8: CSRF (Cross Site Request Forgery)
EXPLANATION: When the attacker forces a victim's browser to send a forged http request including the victim's session cookie and other info to a malicious site(their own) to accomplish something(like deleting their account)
 
FIX: Use a session token. Check the token on every request. Malicious attacker cannot forge teh token since its randomly 	generated.
	For example in the php code fix this by:

$_SESSION['page_token'] = rand()
$_token = $_SESSION['page token']
elseif($token_match && $operation == "deleteExpression")
elseif($token_match && $operation == "addExpression")
elseif($token_match && $operation == "logout")
*/

	} elseif($operation == "delete"){
		$id = $_REQUEST['id'];
		$dbconn = pg_connect_db();
		$result = pg_prepare($dbconn, "", "DELETE FROM secret WHERE id=$1");
		$result = pg_execute($dbconn, "", array($id));
	} elseif($operation == "add"){
		$stext=$_REQUEST['stext'];
		$username=$_SESSION['username'];
		$dbconn = pg_connect_db();
		$query = "INSERT INTO SECRET (username, stext) values ('$username', '$stext');";
		$result = pg_query($dbconn, $query);
	} elseif($operation == "logout"){
		unset($_SESSION);
		$_SESSION['isLoggedIn']=False;
	}
	$g_isLoggedIn=$_SESSION['isLoggedIn']; 
	$g_username=$_SESSION['username']; 
	$g_errors = "";
?>
<html>
	<body>
		<center>
		<h1>Secrets</h1>
		<font color="red"><?=$g_errors ?></font><br/><br/>
		<? if($g_isLoggedIn){ ?>
			<a href=index.php?operation=logout>Logout</a>
			<form method="post" action="index.php">
				<td><input type="text" name="stext"/> </td>
				<td><input type="submit" value="add"/></td>
				<input type="hidden" name="operation" value="add"/>
				<input type="hidden" name="username" value="<?=$g_username ?>"/>
			</form>
			<table>
				<tr>
					<th></th><th>Secret</th>
				</tr>
			<?php
				$dbconn = pg_connect_db();
				$result = pg_prepare($dbconn, "", "SELECT id,username,stext from secret where username=$1 ORDER BY id");
				$result = pg_execute($dbconn, "", array($g_username));
				while ($row = pg_fetch_array($result)) {
					$id=$row["id"];
					$username=$row["username"];
					$stext=$row["stext"];
					if($expressionAccountId==$g_accountId){
						$deleteLink="<a href=\"index.php?operation=delete&id=$id\"><img src=\"delete.png\" width=\"20\" border=\"0\" /></a>";
					} else {
						$deleteLink="";
					}
					echo("<tr> <td>$deleteLink</td><td>$stext</td></tr>");
				}
			?>
			</table>
		<? } else { ?>
			<form method="post" action="index.php">
				<table>
					<tr>
						<td>user name: <input type="text" size="10" name="username"/></td>
						<td>passwd: <input type="password" size="10" name="passwd"/> </td>
						<td>
							<input type="hidden" name="operation" value="login"/>
							<input type="submit" value="login"/>
						</td>
					</tr>
					<tr>
						<td colspan="3"><?php echo($g_debug); ?></td>
					</tr>
				</table>
			</form>
		<? } ?>
		</center>
	</body>
</html>
