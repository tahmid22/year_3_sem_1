<?
        session_start(); 

	if(!isset($_SESSION['isLoggedIn']))$_SESSION['isLoggedIn']=False;
	$operation=$_REQUEST['operation'];
	$g_debug="";
	$g_errors="";

	require "lib/lib.php";
	if($operation == "login"){
		$username=$_REQUEST['username'];
		$passwd=$_REQUEST['passwd'];
		$dbconn = pg_connect_db();

	+--------------------------------------------------------------------------
	| OWASP 2013 A1: INJECTION (SQL Injection)
	| EXPLANATION: Though it looks like this is using a prepared statement, 
	| in fact ... (COMPLETE THIS)
	+--------------------------------------------------------------------------

		$query= "SELECT username, passwd FROM account WHERE username='$username' AND passwd='$passwd'";
		$result = pg_prepare($dbconn, "", $query);
		$result = pg_execute($dbconn, "", array());
		if($row = pg_fetch_row($result)) {
			$_SESSION['username']=$row[0];
			$_SESSION['isLoggedIn']=True;
		} else {
			$g_debug = "$username not logged in";
			$_SESSION['isLoggedIn']=False;
		}
	} elseif($operation == "delete"){
		$id = $_REQUEST['id'];
		$dbconn = pg_connect_db();
		$result = pg_prepare($dbconn, "", "DELETE FROM secret WHERE id=$1");
		$result = pg_execute($dbconn, "", array($id));
	} elseif($operation == "add"){
		$stext=$_REQUEST['stext'];
		$username=$_SESSION['username'];
		$dbconn = pg_connect_db();
		$query = "INSERT INTO SECRET (username, stext) values ('$username', '$stext');";
		$result = pg_query($dbconn, $query);
	} elseif($operation == "logout"){
		unset($_SESSION);
		$_SESSION['isLoggedIn']=False;
	}
	$g_isLoggedIn=$_SESSION['isLoggedIn']; 
	$g_username=$_SESSION['username']; 
	$g_errors = "";
?>
<html>
	<body>
		<center>
		<h1>Secrets</h1>
		<font color="red"><?=$g_errors ?></font><br/><br/>
		<? if($g_isLoggedIn){ ?>
			<a href=index.php?operation=logout>Logout</a>
			<form method="post" action="index.php">
				<td><input type="text" name="stext"/> </td>
				<td><input type="submit" value="add"/></td>
				<input type="hidden" name="operation" value="add"/>
				<input type="hidden" name="username" value="<?=$g_username ?>"/>
			</form>
			<table>
				<tr>
					<th></th><th>Secret</th>
				</tr>
			<?php
				$dbconn = pg_connect_db();
				$result = pg_prepare($dbconn, "", "SELECT id,username,stext from secret where username=$1 ORDER BY id");
				$result = pg_execute($dbconn, "", array($g_username));
				while ($row = pg_fetch_array($result)) {
					$id=$row["id"];
					$username=$row["username"];
					$stext=$row["stext"];
					if($expressionAccountId==$g_accountId){
						$deleteLink="<a href=\"index.php?operation=delete&id=$id\"><img src=\"delete.png\" width=\"20\" border=\"0\" /></a>";
					} else {
						$deleteLink="";
					}
					echo("<tr> <td>$deleteLink</td><td>$stext</td></tr>");
				}
			?>
			</table>
		<? } else { ?>
			<form method="post" action="index.php">
				<table>
					<tr>
						<td>user name: <input type="text" size="10" name="username"/></td>
						<td>passwd: <input type="password" size="10" name="passwd"/> </td>
						<td>
							<input type="hidden" name="operation" value="login"/>
							<input type="submit" value="login"/>
						</td>
					</tr>
					<tr>
						<td colspan="3"><?php echo($g_debug); ?></td>
					</tr>
				</table>
			</form>
		<? } ?>
		</center>
	</body>
</html>
