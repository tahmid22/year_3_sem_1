#!/bin/bash
# Firewall script, see requirement inline
# See the helpful comments at the end of the script!!!
#
#	The firewall has two interfaces, 
# 	eth0 with IP 34.42.10.3 on the 34.43.10.* network <- public
#	eth1 with IP 192.168.1.1 on the 192.168.1.* networks <- private
#
#- The firewall is running an administrative program on port 4444. This program is accessible 
#	only from the 192.168.1.* network.
# flush
/sbin/iptables -F 
/sbin/iptables -F -t nat
/sbin/iptables -F -t mangl

# default drop
/sbin/iptables -P INPUT DROP
/sbin/iptables -P OUTPUT DROP
/sbin/iptables -P FORWARD DROP

/sbin/iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
/sbin/iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
/sbin/iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT


/sbin/iptables -A INPUT -s 192.168.1.0/24 -d -p tcp --dport 4444 -j ACCEPT



# It appears that 70.27.34.11 is a hackers machine. The logs indicate
#	that they are trying to break into the corporate network. iptables
#	should deny 70.27.34.11 access to all services on the network.

/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -d 192.168.1.0/24 -j DROP

#
#- 192.168.1.2 is the system administrators system. 
#	This is the only host that is permitted general connections into (not passing through) the firewall. 
#	192.168.1.2 can remote desktop to any of the desktop systems in the network.

/sbin/iptables -A INPUT -s 192.168.1.0/24 -d 192.168.1.1 -j ACCEPT
/sbin/iptables -A INPUT -s 192.168.1.0/24 -d 34.43.10.0/24 -p tcp --dport 3389 -j ACCEPT
/sbin/iptables -A INPUT -s 192.168.1.0/24 -d 192.168.1.0/24 -p tcp --dport 3389 -j ACCEPT
#
#- 192.168.1.5 is running a web server. All requests for 34.42.10.3 (port 80) are redirected
#	to 192.168.1.5 (port 80). 

/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 34.42.10.0/24 --dport 80 -j DNAT --to 192.168.1.5:80
/sbin/iptables -A FORWARD -d 192.168.1.5 -s 34.42.10.0/24 -p tcp --dport 80 -j ACCEPT

#
#- 192.168.1.7 is the CEO's desktop system. 
#	She would like to run remote desktop from her home system
#	70.27.41.29 to access her office desktop. The firewall should forward 
#	remote desktop requests (port 3389) from 70.27.41.29 to 192.168.1.7.
#

/sbin/iptables -t nat -A PREROUTING -i eth1 -p tcp -s 70.27.41.29 --dport 3389 -j DNAT --to 192.168.1.7:80
/sbin/iptables -A FORWARD -d 192.168.1.7 -s 70.27.41.29 -p tcp --dport 80 -j ACCEPT

#- The firewall is running NAT for the 192.168.1.* network, that is, 
# 	all hosts on the 192.168.1.* network share the same external IP (34.42.10.3).
#
/sbin/iptables -t nat -A POSTROUTING -o eth0 -j SNAT --to 34.42.10.3

#- It appears that 70.27.34.11 is a hackers machine. The logs indicate
#	that they are trying to break into the corporate network. iptables
#	should deny 70.27.34.11 access to all services on the network.

# ********************Handled at the very beginning, because the way I am doing it, that order is necessary


#
#- All other connections into the 192.168.1.* network and the firewall should be denied.
#
################################################################################


################################################################################
# SOME USEFUL COMMENTS
#/sbin/iptables -F 
#/sbin/iptables -F -t nat
#/sbin/iptables -F -t mangle
#/sbin/iptables -P INPUT ACCEPT
#/sbin/iptables -P OUTPUT ACCEPT
#/sbin/iptables -P FORWARD ACCEPT
#/sbin/iptables -P INPUT DROP
#/sbin/iptables -P OUTPUT DROP
#/sbin/iptables -P FORWARD DROP
#/sbin/iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
#/sbin/iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
#/sbin/iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT
#/sbin/iptables -A INPUT -s 10.10.10.11 -p tcp --dport 22 -j ACCEPT
#/sbin/iptables -A OUTPUT -d 10.10.10.75 -p tcp --sport 22 -j ACCEPT
#/sbin/iptables -A FORWARD -d 192.168.0.100 -p tcp --dport 80 -j ACCEPT
#/sbin/iptables -A FORWARD -d 192.168.0.100 -s 10.10.10.13 -p tcp --dport 22 -j ACCEPT
#/sbin/iptables -A FORWARD -s 192.168.0.100 -p tcp --sport 80 -j ACCEPT
#/sbin/iptables -A FORWARD -d 192.168.0.0/24 -j DROP
#/sbin/iptables -t nat -A PREROUTING -i eth0 -d 192.168.0.0/24 -j DROP
#/sbin/iptables -t nat -A PREROUTING -i eth0 -s 10.10.10.13 -p tcp --dport 22 -j DNAT --to 192.168.0.100
#/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp --dport 80 -j DNAT --to 192.168.0.100
#/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.11 --dport 2222 -j DNAT --to 192.168.0.100:22
#/sbin/iptables -t filter -A INPUT -s 192.168.0.15 -p tcp --dport 22 -j ACCEPT
#/sbin/iptables -A FORWARD -d 192.168.0.100 -p tcp --dport 80 -j ACCEPT
#/sbin/iptables -A FORWARD -i eth1 -j ACCEPT
#/sbin/iptables -t nat -A POSTROUTING -o eth0 -j SNAT --to 10.10.10.10
################################################################################
