#PUT YOUR ANSWERS TO THE FIREWALL QUESTION HERE.
# Submit your firewall script annotated so that it is clear which parts of your script accomplish which parts of this question.

#!/bin/bash

/sbin/iptables -F 
/sbin/iptables -F -t nat
/sbin/iptables -F -t mangle

# default policy ACCEPT
# /sbin/iptables -P INPUT ACCEPT
# /sbin/iptables -P OUTPUT ACCEPT
# /sbin/iptables -P FORWARD ACCEPT

# default policy DROP <- Whitelisting
/sbin/iptables -P INPUT DROP
/sbin/iptables -P OUTPUT DROP
/sbin/iptables -P FORWARD DROP

/sbin/iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
/sbin/iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
/sbin/iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT



# ========================== ADDED NEW ==============================

# 4(a) The 10.10.10.* network is the public network.
# The 192.168.0.* is the private network, so all public hosts access 10.10.10.10 only. 

# Goal: Allow 10.10.10.* on any port on the Firewall only.

/sbin/iptables -A INPUT -s 10.10.10.0/24 -d 10.10.10.10 -j ACCEPT

# Make sure 10.10.10.* cannot directly talk to 192.168.0.*
/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -d 192.168.0.0/24 -j DROP

#4g
/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.128 -j DROP

# _____________________________ END ________________________________


# ==========================ADDED NEW ===============================

# 4(c) Allow 192.168.0.75 to ssh into the firewall.
# No other access into the firewall is permitted.

# Goal: Allow 192.168.0.75 to ssh onto Firewall only.

/sbin/iptables -A INPUT -s 192.168.0.75 -p tcp --dport 22 -j ACCEPT 

# ______________________________ END ________________________________ 


# =========================== ADDEED NEW ============================

# 4(b) Configure your firewall so that external http and stmp traffic can get to your web/server (the Ubuntu Box).

# Goal: Re-route external http and smtp traffic from 10.10.10.* to get to web server through firewall by accessing eth0(10.10.10.10) only.

/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.0/24 --dport 80 -j DNAT --to 192.168.0.100:80

/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.0/24 --dport 25 -j DNAT --to 192.168.0.100:25 

/sbin/iptables -A FORWARD -d 192.168.0.100 -s 10.10.10.0/24 -p tcp --match multiport --dports 80,25 -j ACCEPT

# _______________________________ END _______________________________


# =========================== ADDED NEW =============================

# 4(d) Allow 10.10.10.75 (outside the local network) to ssh into tge web.mail server by using port 2222 on the external side of the firewall.
# This is only external ssh access allowed into the web/mail server (the Ubuntu box).

# Goal: Allow 10.10.10.75 to ssh into web/mail server by using port 2222

/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.75 --dport 2222 -j DNAT --to 192.168.0.100:22

/sbin/iptables -A FORWARD -d 192.168.0.100 -s 10.10.10.75 -p tcp --dport 22 -j ACCEPT

# _______________________________ END _______________________________


# =========================== ADDED NEW ==============================

# 4(f) The CEO has a windows box inside the private network (192.168.0.33).
# The CEO (with fixed IP 10.10.10.33) would like to have remote desktop access to his desktop. Configure your firewall so that this is the case.
#The CEOs windows machine should have RDP restricted so that only their external machine can connect.

# Goal: 10.10.10.33 would like to have remote desktop access to 192.168.0.33 and only 10.10.10.33.

/sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.33 --dport 3389 -j DNAT --to 192.168.0.33:3389 

/sbin/iptables -A FORWARD -d 192.168.0.33 -s 10.10.10.33 -p tcp --dport 3389 -j ACCEPT

# _______________________________ END _______________________________


# ============================ ADDED NEW ============================

# 4(g) Sid, would also like to RDP access to his windows box (with fixed IP 192.168.0.37) from his home at fixed IP 10.10.10.211.

# Can IP tables be used to do this as well?
# Answer: Yes. Follow the same procedure as 4(f) as follows
# /sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.211 --dport 3389 -j DNAT --to 192.168.0.37:3389 
# /sbin/iptables -A FORWARD -d 192.168.0.37 -s 10.10.10.211 -p tcp --dport 3389 -j ACCEPT


# What if we want both to use the same RDP port on the firewall?
# Answer: Yes both can use the same RDP port on the firewall.
# Also since firewall preroutes based on source IP address, they will have RDP service to their own machines only.

# No access to any services from 10.10.10.128 should be allowed. 
# Handled in 4g

# ________________________________ END ______________________________


# ============================ ADDED NEW ============================

# 4(h) All machines inside the private network have their dafault route set to 192.168.0.10. 
# All external machines know nothing about the internal network.
# Their default route can be set to 10.10.10.99 (a non-real machine)

# Yes all machines inside the private network have their default route set to 192.168.0.10 already
# Yes all external machines know nothing about the internal network which has been taken care of.
# All external machine's dafault route can be set to 10.10.10.99 by setting up the network that way. 

# ______________________________ END ________________________________


# ============================ ADDED NEW ============================

# 4(i) Finally, imagine that the only routable IP is 10.10.10.10.
# All internal machines should share this IP for internet traffic.

/sbin/iptables -t nat -A POSTROUTING -o eth0 -j SNAT --to 10.10.10.10

# ______________________________ END ________________________________



# ++++++++++++++++++++++++++++ Previos rules ++++++++++++++++++++++++

# /sbin/iptables -A FORWARD -d 192.168.0.100 -p tcp --dport 80 -j ACCEPT
# /sbin/iptables -A FORWARD -d 192.168.0.100 -s 10.10.10.11 -p tcp --dport 22 -j ACCEPT
# /sbin/iptables -A FORWARD -s 192.168.0.100 -p tcp --sport 80 -j ACCEPT

### /sbin/iptables -A FORWARD -d 192.168.0.0/24 -j DROP
##
## /sbin/iptables -t nat -A PREROUTING -i eth0 -d 192.168.0.0/24 -j DROP
# /sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp --dport 80 -j DNAT --to 192.168.0.100
# /sbin/iptables -t nat -A PREROUTING -i eth0 -p tcp -s 10.10.10.75 --dport 2222 -j DNAT --to 192.168.0.100:22
##
## /sbin/iptables -t filter -A INPUT -s 192.168.0.15 -p tcp --dport 22 -j ACCEPT
#
## /sbin/iptables -A FORWARD -d 192.168.0.100 -p tcp --dport 80 -j ACCEPT
## /sbin/iptables -A FORWARD -i eth1 -j ACCEPT
##
##
#/sbin/iptables -t nat -A POSTROUTING -o eth0 -j SNAT --to 10.10.10.10

# ----------------------- END of previos rules ----------------------


